package partitionproblembruteforcerecursive;

public class PartitionProblemBFRecursive {
    
    public static void main(String[] args) {
        ParserArgs pargs = new ParserArgs(args); 
        pargs.parserArg();
    }
}
