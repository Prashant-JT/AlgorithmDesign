#include "BruteForceIt.h"

BruteForceIt::BruteForceIt(int* num, int size) {
    this->num = num;
    this->n = size;
}

void BruteForceIt::printVector() {
    cout << "| ";
    for (int i = 0; i < n; i++) {
        cout << num[i] << " | ";
    }
    cout << endl;
}

void BruteForceIt::getResult() {
    cout << "Results: " << sum << endl;
    
    /*string set1 = "{";
    string set2 = "{";
    int x = n;
    int currSum = sum;
    
    while (x > 0 && currSum >= 0){
         
        if (dp[x-1][currSum]){ 
            x--;
            set1 += to_string(num[x]) + ", ";                
        }else if (dp[x-1][currSum - num[x-1]]){ 
            x--; 
            currSum -= num[x]; 
            set2 += to_string(num[x]) + ", "; 
        } 
    } 
    
    set1 = set1.substr(0, set1.length()-2) + '}';
    set2 = set2.substr(0, set2.length()-2) + '}';
    cout << "Set 1: " << set1 << endl;
    cout << "Set 2: " << set2 << endl;*/
}

void BruteForceIt::printResult() {
    if(found){
        cout << "\nVector can be partitioned" << endl;
        BruteForceIt::getResult();
    }else{
        cout << "\nVector can not be partitioned" << endl;
    }
}

void BruteForceIt::printTime(long timeMS, long timeNS, string scale) {
    printf("For %d elements -> Taken time: ", n); 
    float print = (float) ((timeMS == 0)? timeNS/1e9 : timeMS/1e3);
    if(scale.empty()){
        printf("%.8f s.\n", print);
    }else{
        if(scale == "ns"){
            cout << timeNS << " " << scale << '.' << endl;
        }else if(scale == "ms"){
            cout << timeMS << " " << scale << '.' << endl;
        }else{
            printf("%.8f s.\n", print);
        }
    }
}

int BruteForceIt::add() {
    for (int i = 0; i < n; i++) sum += num[i];
        
    return sum;
}

bool BruteForceIt::canPartition() {
    int sum = add();
    return (sum % 2 == 0);
}

void BruteForceIt::canPartitionIterator() {
    sum /= 2;    
    IteratorCombinations* it = new IteratorCombinations(num, sum, n);
    while(!it->lastCombination()){
        it->nextCombination();
        if(it->searchedCombination()) found = true;
    }
    delete(it);
}

