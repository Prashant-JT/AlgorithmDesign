import random
from time import time

def can_partition(num):
  s = sum(num)

  # if 's' is a an odd number, we can't have two subsets with equal sum
  if s % 2 != 0:
    return False

  # initialize the 'dp' array, -1 for default, 1 for true and 0 for false
  dp = [[-1 for x in range(int(s/2)+1)] for y in range(len(num))]
  

  def can_partition_recursive(n , s):
    # base check
    if s == 0:
      return 1

    if n < 0:
      return 0

    # if we have not already processed a similar problem
    if dp[n][s] == -1:
      # recursive call after choosing the number at the currentIndex
      # if the number at currentIndex exceeds the sum, we shouldn't process this
      if num[n] <= s:
        if can_partition_recursive( n - 1, s - num[n]) == 1:
          dp[n][s] = 1
          return 1

      # recursive call after excluding the number at the currentIndex
      dp[n][s] = can_partition_recursive(n - 1, s)

    return dp[n][s]

  return True if can_partition_recursive(len(num)-1, int(s/2)) == 1 else False
  


def main():
  num=[6, 5, 2, 1]
  #vector =[]
  #for i in range(0, 20):
  #  vector.append(random.randrange(100))
  tiempoInicial=time()
  found=can_partition(num)
  tiempoFinal=time()
  tiempoEjecuccion=tiempoFinal-tiempoInicial
  print("Can partition: " + str(found))
  print("El tiempo es " + str(tiempoEjecuccion))


main()