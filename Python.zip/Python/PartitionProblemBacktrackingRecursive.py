import random
from time import time

def can_partition(num):
  s = sum(num)
  # if 's' is a an odd number, we can't have two subsets with equal sum
  if s % 2 != 0:
    return False

  def can_partition_recursive(n, s):
    # base check 
    # find subset with equal sum than other subset
    if s == 0:
      return True
    # reach the end of the vector num, we cannot find subset with equal sum than other subset
    if n < 0:
      return False

    # can reduce s 
    if num[n] <= s:
      if can_partition_recursive(n - 1, s - num[n]): 
        return True

    # cannot reduce s
    return can_partition_recursive(n - 1, s)

  # if s is an even number, we have to look for two subsets with equal sum
  
  return can_partition_recursive(len(num) - 1, int (s / 2))

def main():
  num=[6, 5, 2, 1]
  #vector =[]
  #for i in range(0, 20):
  #  vector.append(random.randrange(100))
  tiempoInicial=time()
  found=can_partition(num)
  tiempoFinal=time()
  tiempoEjecuccion=tiempoFinal-tiempoInicial
  print("Can partition: " + str(found))
  print("El tiempo es " + str(tiempoEjecuccion))


main()