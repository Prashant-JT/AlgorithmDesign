import time

def readFile(v):
    try:
        file = "../../../fichVect.txt"
        #files = os.listdir(args.folder)
        #Nfiles = len(files)
        #if Nfiles == 0: sys.exit("Directory doesn't contain vector, for help use the -h option")
    except Exception as e:
        print(e)
        sys.exit("Directory Not Found, for help use the -h option")
    try:
        f = open(file, 'r')
        N = int (f.readline())
        for j in range (N):
            element = f.readline()
            v.append(int(element))
    except Exception as e:
        print(e)
        sys.exit("Vector is not named in the correct way, for help use the -h option")
    finally:
        f.close()

def showTree(sum, currentIndex, caso):
  print("CurrentIndex " + str(currentIndex))
  print("Sum " + str(sum))
  print(caso)
  print()

def can_partition(num):
  s = sum(num)
  if s % 2 != 0:
    return False

  return can_partition_recursive(num, s / 2, 0)

def can_partition_recursive(num, sum, currentIndex):
  # base check
  if sum == 0:
    #showTree(sum, currentIndex, "caso base, encontrado")
    return True

  n = len(num)
  if n == 0 or currentIndex >= n:
    #showTree(sum, currentIndex, "caso base, no encontrado")
    return False

  # recursive call after choosing the number at the `currentIndex`
  # if the number at `currentIndex` exceeds the sum, we shouldn't process this
  if num[currentIndex] <= sum:
    #showTree(sum, currentIndex, "irse izquierda")
    if(can_partition_recursive(num, sum - num[currentIndex], currentIndex + 1)):
      return True

  # recursive call after excluding the number at the 'currentIndex'
  #showTree(sum, currentIndex, "irse derecha")
  return can_partition_recursive(num, sum, currentIndex + 1)

if __name__ == '__main__':
  v = []
  readFile(v)
  print("v = ", v)
  found=can_partition(v)
  print("Can partition: " + str(found))