#ifndef MEMOIZATION_H
#define MEMOIZATION_H

#include <map>
#include <iostream>
#include <string>

using namespace std;

class Memoization {
    private:
        int* num;
        map<string, bool> mp;
        int n;
        int sum = 0;
        bool found;
        void getResult();
        int add();
        bool canPartitionMemo(int i, int s);
    public:
        Memoization(int* num, int size);
        void printVector();
        void printResult();
        void printTime(long timeMS, long timeNS, string scale);
        bool canPartition();
        void canPartitionAux();
};

#endif /* MEMOIZATION_H */

