package partitionproblembruteforcerecursive;

public class PartitionProblemBruteForceRecursive {
    
    private static boolean[] combination;
    private static boolean found;

    private static int sum(int[] num) {
        int total = 0;
        // sumar el valor de cada elemento al total
        for (int contador = 0; contador < num.length; contador++) {
            total += num[contador];
        }
        return total;
    }
    
    public static void main(String[] args) {
        PartitionProblemBruteForceRecursive ps = new PartitionProblemBruteForceRecursive();
        int[] num = new int []{1, 1, 3, 4, 7};
        int size = num.length - 1;
        combination = new boolean [num.length];
        boolean found = canPartition(num, size);
        System.out.println("Can partition " + found);
    }

    private static boolean canPartition(int[] num, int size) {
        int s = sum(num);
        if (s % 2 != 0){
            return false;
        }
        canPartitionRecursive(num, s/2, size);
        return found;
    }

    private static void canPartitionRecursive(int[] num, int sum, int size) {
        if (size == 0){
            searchedCombination(num, sum);
        } else {
            combination[size]=true;
            canPartitionRecursive(num, sum, size - 1);
            combination[size]=false;
            canPartitionRecursive(num, sum, size - 1);
        }
    }

    private static void searchedCombination(int[] num, int previousSum) {
        int actualSum=0;
        for (int i = 0; i < num.length; i++) {
            if (combination[i] == true){
                actualSum= actualSum + num[i];
            }    
        }
        if (actualSum==previousSum){
            found=true;
        }     
    }
    
}
