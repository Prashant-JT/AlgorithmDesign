
package partitionproblembruteforceiterator;


public class PartitionProblemBruteForceIterator {

    private static int sum(int[] num) {
        int total = 0;
        // sumar el valor de cada elemento al total
        for (int contador = 0; contador < num.length; contador++) {
            total += num[contador];
        }
        return total;
    }
    
    public static void main(String[] args) {
        PartitionProblemBruteForceIterator ps = new PartitionProblemBruteForceIterator();
        int[] num = new int []{1, 1, 3, 4, 7};
        boolean found = canPartition(num);
        System.out.println("Can partition " + found);
    }

    private static boolean canPartition(int[] num) {
        int s = sum(num);
        if (s % 2 != 0){
            return false;
        }
        return canPartitionIterator(num, s/2);
    }

    private static boolean canPartitionIterator(int[] num, int sum) {
        boolean found = false;
        IteradorCombinaciones it = new IteradorCombinaciones(num.length);
        while (! it.ultimaCombinacion()){
            it.siguienteCombinacion();
            if (it.searchedCombination(num, sum)){
                found = true;
            }
        }
        return found;
    }   
}
