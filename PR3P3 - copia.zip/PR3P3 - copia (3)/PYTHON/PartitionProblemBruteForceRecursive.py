import random
from time import time

class auxiliar:
  combination =[]
  found=False

def showCombination(combination):
    for i in range(0, len(combination)):
        if combination[i] == 1:
            print("1 ", end="")
        else: 
            print("0 " , end="")
    print()

def show_searchedCombination(combination, num, sum):
    for i in range(0, len(combination)):
        if combination[i] == 1:
            print("1 ", end="")
        else: 
            print("0 " , end="")
    print()
    print ("Los dos subconjutos cuya suma es " + str(sum) + " son :")
    for i in range(0, len(combination)):
        if combination[i] == 1:
            print( str(num[i]) + " ", end="")
    print()
    for i in range(0, len(combination)):
        if combination[i] == 0:
            print(str(num[i]) + " ", end="")
    print()
    print()

def searchedCombination(num, previousSum):
  actualSum=0
  for i in range(0, len(num)):
    if auxiliar.combination[i] == True:
      actualSum= actualSum + num[i]
  if actualSum == previousSum:                  
    #show_searchedCombination(auxiliar.combination, num, actualSum)
    auxiliar.found=True

def can_partition(num, size):
  
  s = sum(num)
  # if 's' is a an odd number, we can't have two subsets with equal sum
  if s % 2 != 0:
    return False

  can_partition_Recursive(num, s / 2, size)
  return auxiliar.found


def can_partition_Recursive(num, sum, size):  
    if size == 0:
      searchedCombination(num, sum)
    else:
      auxiliar.combination[size] = True
      #showCombination(auxiliar.combination)
      can_partition_Recursive(num, sum, size - 1)
      auxiliar.combination[size] = False
      #showCombination(auxiliar.combination)
      can_partition_Recursive(num, sum, size - 1)

if __name__ == "__main__":
  #num=[1, 1, 3, 4, 7]
  for i in range(0, 20):
    auxiliar.combination.append(False)
  vector =[]
  for i in range(0, 20):
    vector.append(random.randrange(100))
  tiempoInicial=time()
  found=can_partition(vector,20-1)
  tiempoFinal=time()
  tiempoEjecuccion=tiempoFinal-tiempoInicial
  print("Can partition: " + str(found))
  print("El tiempo es " + str(tiempoEjecuccion))
    
        