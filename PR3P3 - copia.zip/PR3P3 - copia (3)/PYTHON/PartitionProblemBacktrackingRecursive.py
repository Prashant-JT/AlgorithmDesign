import random
from time import time

def showTree(sum, currentIndex, caso):
  print("CurrentIndex " + str(currentIndex))
  print("Sum " + str(sum))
  print(caso)
  print()

def can_partition(num):
  s = sum(num)
  # if 's' is a an odd number, we can't have two subsets with equal sum
  if s % 2 != 0:
    return False

  return can_partition_recursive(num, s / 2, 0)

def can_partition_recursive(num, sum, currentIndex):
  
  # base check
  if sum == 0:
    #showTree(sum, currentIndex, "caso base, encontrado")
    return True

  n = len(num)
  if n == 0 or currentIndex >= n:
    #showTree(sum, currentIndex, "caso base, no encontrado")
    return False

  # recursive call after choosing the number at the `currentIndex`
  # if the number at `currentIndex` exceeds the sum, we shouldn't process this
  if num[currentIndex] <= sum:
    #showTree(sum, currentIndex, "irse izquierda")
    if(can_partition_recursive(num, sum - num[currentIndex], currentIndex + 1)):
      return True

  # recursive call after excluding the number at the 'currentIndex'
  #showTree(sum, currentIndex, "irse derecha")
  return can_partition_recursive(num, sum, currentIndex + 1)


def main():
  #num=[1, 1, 3, 4, 7]
  vector =[]
  for i in range(0, 20):
    vector.append(random.randrange(100))
  tiempoInicial=time()
  found=can_partition(vector)
  tiempoFinal=time()
  tiempoEjecuccion=tiempoFinal-tiempoInicial
  print("Can partition: " + str(found))
  print("El tiempo es " + str(tiempoEjecuccion))


main()