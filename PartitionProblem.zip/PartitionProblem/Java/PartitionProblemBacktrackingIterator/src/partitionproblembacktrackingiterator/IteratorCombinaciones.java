package partitionproblembacktrackingiterator;

import static java.lang.System.exit;

class IteradorCombinaciones {

    private int [] combinacion;
    private int valormaximo;
    private int valorminimo;

    public IteradorCombinaciones(int N) {
        this.combinacion = new int[N];
        this.valormaximo = 1;
        this.valorminimo = 0;
    }

    public boolean ultimaCombinacion() {
        for (int i = 0; i < combinacion.length; i++) {
            if (combinacion[i] == 0) {
                return false;
            }
        }
        return true;
    }

    public int[] siguienteCombinacion(int [] num, int suma, boolean found) {
        for (int i = 0; i < combinacion.length; i++) {
            if (combinacion[i] == valormaximo) {
                combinacion[i] = valorminimo;
            } else {
                combinacion[i] = combinacion[i] + 1;
                if (isValidCombination(combinacion, num, suma)){
                    return combinacion;
                } else {
                    combinacion[i]= valorminimo;
                }
            }
        }
        NoMoreCombinations(found);
        return null;
    }
    
    public boolean searchedCombination(int[] num, int previousSum){
        int actualSum = totalValues(num);
        if (actualSum==previousSum){
            return true;
        }
        return false;
    }

    private boolean isValidCombination(int[] combinacion, int[] num, int suma) {
        return totalValues(num) <= suma;
    }

    private int totalValues(int [] num) {
        int suma=0;
        for (int i = 0; i < num.length; i++) {
            if (combinacion[i] == 1){
                suma= suma + num[i];
            }
        }
        return suma;
    }

    private void NoMoreCombinations(boolean found) {
        System.out.println("Can partition: " + found);
        exit(0);
    }
}