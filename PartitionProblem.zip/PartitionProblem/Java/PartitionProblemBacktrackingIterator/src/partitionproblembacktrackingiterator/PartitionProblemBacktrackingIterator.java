
package partitionproblembacktrackingiterator;


public class PartitionProblemBacktrackingIterator {

    private static int sum(int[] num) {
        int total = 0;
        // sumar el valor de cada elemento al total
        for (int contador = 0; contador < num.length; contador++) {
            total += num[contador];
        }
        return total;
    }
    
    public static void main(String[] args) {
        PartitionProblemBacktrackingIterator ps = new PartitionProblemBacktrackingIterator();
        int[] num = new int []{1, 1, 3, 4, 7};
        boolean found = canPartition(num);
        System.out.println("Can partition " + found);
    }

    private static boolean canPartition(int[] num) {
        int s = sum(num);
        if (s % 2 != 0){
            return false;
        }
        return canPartitionIterator(num, s/2);
    }

    private static boolean canPartitionIterator(int[] num, int sum) {
        int[] combination = new int [num.length];
        boolean found = false;
        IteradorCombinaciones it = new IteradorCombinaciones(num.length);
        while (! it.ultimaCombinacion()){
            combination = it.siguienteCombinacion(num, sum, found);
            if (it.searchedCombination(num, sum)){
                found = true;
            }
        }
        return found;
    }   
}
