from IteratorCombinaciones import *
import random
from time import time

def show_searchedCombination(combination, num, sum):
    for i in range(0, len(combination)):
        if combination[i] == 1:
            print("1 ", end="")
        else: 
            print("0 " , end="")
    print()
    print ("Los dos subconjutos cuya suma es " + str(sum) + " son :")
    for i in range(0, len(combination)):
        if combination[i] == 1:
            print( str(num[i]) + " ", end="")
    print()
    for i in range(0, len(combination)):
        if combination[i] == 0:
            print(str(num[i]) + " ", end="")
    print()
    print()

def showCombination(combination):
    for i in range(0, len(combination)):
        if combination[i] == 1:
            print("1 ", end="")
        else: 
            print("0 " , end="")
    print()

def can_partition(num):
  s = sum(num)
  # if 's' is a an odd number, we can't have two subsets with equal sum
  if s % 2 != 0:
    return False

  return can_partition_Iterator(num, s / 2)

def can_partition_Iterator(num, sum):
    combination = []
    found = False
    it = IteratorCombinaciones(len(num))
    while not it.endOfCombinations():
        combination = it.nextCombination()
        if it.searchedCombination(num, sum):
            #show_searchedCombination(combination, num, sum)
            found = True
        #showCombination(combination)
    return found

if __name__ == "__main__":
  #num=[1, 1, 3, 4, 7]
  vector =[]
  for i in range(0, 20):
    vector.append(random.randrange(100))
  tiempoInicial=time()
  found=can_partition(vector)
  tiempoFinal=time()
  tiempoEjecuccion=tiempoFinal-tiempoInicial
  print("Can partition: " + str(found))
  print("El tiempo es " + str(tiempoEjecuccion))
    
        