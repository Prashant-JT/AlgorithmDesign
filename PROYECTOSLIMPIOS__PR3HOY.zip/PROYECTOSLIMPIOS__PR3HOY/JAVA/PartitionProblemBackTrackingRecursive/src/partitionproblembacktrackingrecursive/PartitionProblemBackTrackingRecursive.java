package partitionproblembacktrackingrecursive;

public class PartitionProblemBackTrackingRecursive {
    
   public static void main(String[] args) {
        ParserArgs pargs = new ParserArgs(args); 
        pargs.parserArg();
    }
}
    