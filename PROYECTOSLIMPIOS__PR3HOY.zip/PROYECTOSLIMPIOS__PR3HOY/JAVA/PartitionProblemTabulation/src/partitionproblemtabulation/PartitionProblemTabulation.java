package partitionproblemtabulation;

public class PartitionProblemTabulation {
    
    public static void main(String[] args) {
        ParserArgs pargs = new ParserArgs(args); 
        pargs.parserArg();
    }    
}
