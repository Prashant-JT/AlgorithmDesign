package partitionproblemmemoization;

public class PartitionProblemMemoization {
    
    public static void main(String[] args) {
        ParserArgs pargs = new ParserArgs(args); 
        pargs.parserArg();
    }    
}
